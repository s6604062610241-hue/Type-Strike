"""Package the current source and playable version; never generate or change reports."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parents[1]
release = root / 'release'
release.mkdir(exist_ok=True)
version = (root / 'VERSION').read_text().strip()
prefix = 'TypeStrike-v' + version
source_roots = ['src', 'resources', 'tests', 'docs', 'tools', '.vscode']
source_files = ['.gitignore', 'AGENTS.md', 'VERSION', 'VERSIONS.md', 'README.md', 'Build.cmd', 'Play.cmd', 'build.ps1', 'run.ps1', 'test.ps1']
with ZipFile(release / (prefix + '-Source.zip'), 'w', ZIP_DEFLATED) as archive:
    for folder in source_roots:
        for path in sorted((root / folder).rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts:
                archive.write(path, 'TypeStrike/' + path.relative_to(root).as_posix())
    for name in source_files:
        archive.write(root / name, 'TypeStrike/' + name)

with ZipFile(release / (prefix + '-Windows.zip'), 'w', ZIP_DEFLATED) as archive:
    archive.write(root / 'dist/TypeStrike.jar', 'TypeStrike/TypeStrike.jar')
    archive.writestr('TypeStrike/Play.cmd', '@echo off\r\ncd /d "%~dp0"\r\njava -jar "%~dp0TypeStrike.jar"\r\nif errorlevel 1 pause\r\n')
    archive.writestr('TypeStrike/README.txt',
        'Type Strike - Java OOP typing defense game\n\n'
        'Requires Java 21 or newer on Windows.\n'
        'Extract the entire ZIP, then double-click Play.cmd.\n'
        'You can also run: java -jar TypeStrike.jar\n\n'
        'Type an enemy word and press Enter. Escape pauses.\n'
        'Normal enemies: one word. Armored enemies: two different words.\n'
        'Crystal Frost Slime: one word, +20 points and one Slow charge.\n'
        'Space: use Slow for 50% enemy movement for 5 seconds. Stores 3 charges.\n'
        'Escape: pause menu with Resume, Main Menu and Quit.\n'
        'Scores are saved in %USERPROFILE%\\.type-strike\\scores.txt\n'
        'This archive does not include a Java runtime.\n')
for path in release.glob(prefix + '*.zip'):
    print(path.name, path.stat().st_size, 'bytes')
