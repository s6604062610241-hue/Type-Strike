# Type Strike v1.0.0

This is a preserved snapshot of Type Strike (the first playable version).
Version: v1.0.0
Snapshot created: 2026-10-31T22:45:12+07:00 (host clock; the version identifier is authoritative)

## Contents

- project/: source files, resources, tests, build/run scripts, VS Code configuration, tools and all existing docs.
- packages/TypeStrike-v1.0.0-Source.zip: original source distribution.
- packages/TypeStrike-v1.0.0-Windows.zip: portable notebook play distribution; requires Java 21+.
- packages/TypeStrike-v1.0.0.jar: executable game JAR.
- project/docs/OOP-GUIDE.md: OOP explanation.
- project/docs/GAME-DESIGN.md: rules and limitations.
- project/docs/PRESENTATION.md: presentation notes (Markdown, not a slide deck).
- project/docs/TypeStrike-Report-TH.pdf, .md, .html: existing report and editable sources.
- project/docs/images/: report images.
- screenshots/: menu, gameplay, pause, gameover, menu-minimum.
- SHA256SUMS.txt: verified hashes of all other files in this snapshot.

The gameplay and original release packages are unchanged. Version-management files were added to arrange this backup.
Build caches, temporary files, browser profiles and Git internals are excluded; all authored source and requested deliverables are included.
Do not edit this snapshot when developing later versions. Work in the main project folder.
The owner will write the academic report; future work focuses on the game unless documentation is explicitly requested.
This is a local backup, not an upload to GitHub.
