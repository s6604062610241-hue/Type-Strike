Type Strike - Java OOP typing defense game

Requires Java 21 or newer on Windows.
Extract the entire ZIP, then double-click Play.cmd.
You can also run: java -jar TypeStrike.jar

Type an enemy word and press Enter. Escape pauses.
Pink enemies: one word. Gold armored enemies: two different words.
Scores are saved in %USERPROFILE%\.type-strike\scores.txt
This archive does not include a Java runtime.
