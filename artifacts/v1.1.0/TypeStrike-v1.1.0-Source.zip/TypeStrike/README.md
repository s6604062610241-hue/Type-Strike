# Type Strike v1.1.0

Java 21 Swing typing defense game.

Build: open Build.cmd. Play: open Play.cmd after building.
Tests: powershell -NoProfile -ExecutionPolicy Bypass -File test.ps1

Original game source is preserved. Academic documents are stored locally and excluded from this public source package.
