Type Strike - Java OOP typing defense game

Requires Java 21 or newer on Windows.
Extract the entire ZIP, then double-click Play.cmd.
You can also run: java -jar TypeStrike.jar

Type an enemy word and press Enter. Escape pauses.
Normal enemies: one word. Armored enemies: two different words.
Crystal Frost Slime: one word, +20 points and one Slow charge.
Space: use Slow for 50% enemy movement for 4 seconds. Stores 1 charge.
F1/F2/F3: compare the existing themes.
Scores are saved in %USERPROFILE%\.type-strike\scores.txt
This archive does not include a Java runtime.
