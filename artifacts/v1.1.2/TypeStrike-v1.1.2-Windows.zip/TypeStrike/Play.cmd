@echo off
cd /d "%~dp0"
java -jar "%~dp0TypeStrike.jar"
if errorlevel 1 pause
