Type Strike - Java OOP typing defense game

Requires Java 21 or newer on Windows.
Extract the entire ZIP, then double-click Play.cmd.
You can also run: java -jar TypeStrike.jar

Type an enemy word and press Enter. Escape pauses.
Normal enemies: one word. Armored enemies: two different words.
Crystal Frost Slime: one word, +20 points and one Slow charge.
Space: use Slow for 50% enemy movement for 5 seconds. Stores 3 charges.
Escape: pause menu with Resume, Main Menu and Quit.
Scores are saved in %USERPROFILE%\.type-strike\scores.txt
This archive does not include a Java runtime.
